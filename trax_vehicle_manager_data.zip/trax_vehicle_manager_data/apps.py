from django.apps import AppConfig


class TraxVehicleManagerDataConfig(AppConfig):
    name = 'trax_vehicle_manager_data'
